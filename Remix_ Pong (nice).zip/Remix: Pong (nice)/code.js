

var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

// create sprites
var paddle = createSprite(50, 200);
var paddle2 = createSprite(350, 200);
var ball = createSprite(200, 200);
var Upperwall = createSprite(200, 450);
var Lowerwall = createSprite(200, -50);
var group = createGroup();
var groupw = createGroup();
paddle.width = 25;
paddle2.width = 25;
ball.scale = 0.25;
ball.velocityX = -5;
paddle.shapeColor = "white";
paddle2.shapeColor = "white";
ball.shapeColor = "white";
Upperwall.shapeColor = "white";
Lowerwall.shapeColor = "white";
group.add(paddle);
group.add(paddle2);
groupw.add(Upperwall);
groupw.add(Lowerwall);
paddle.velocityX = 0;
Upperwall.width = 400;
Lowerwall.width = 400;
function draw() {
  //move and collisions
  background("black");
  drawSprites();
  if (keyDown("up")) {
    paddle2.velocityY = -8;
  } else if ((keyDown("down"))) {
    paddle2.velocityY = 8;
  } else {
    paddle2.velocityY = 0;
  }
  if (keyDown("w")) {
    paddle.velocityY = -8;
  } else if ((keyDown("s"))) {
    paddle.velocityY = 8;
  } else {
    paddle.velocityY = 0;
  }
  if (ball.isTouching(group)) {
    ball.bounceOff(group);
    playSound("assets/category_pop/retro_game_hit_block_1.mp3", false);
    ball.velocityY = randomNumber(-5, 5);
    ball.velocityX = ball.velocityX * 1.05;
  }
  group.collide(groupw);
  ball.bounceOff(groupw);
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
